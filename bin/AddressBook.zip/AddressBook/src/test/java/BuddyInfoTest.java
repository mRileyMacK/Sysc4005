import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BuddyInfoTest {

    @Test
    public void getName() {
        BuddyInfo b = new BuddyInfo("Jason");
        assert(b.getName().equals("Jason"));
    }

    @Test
    public void setName() {
        BuddyInfo b = new BuddyInfo("Jason");
        b.setName("Thao");
        assert(b.getName().equals("Thao"));
    }

    @Test
    void getAddress() {
        BuddyInfo b = new BuddyInfo("here","123");
        assert(b.getAddress().equals("here"));

    }

    @Test
    void setAddress() {
        BuddyInfo b = new BuddyInfo("Jason");
        b.setAddress("here");
        assert(b.getAddress().equals("here"));
    }

    @Test
    void getPhoneNumber() {
        BuddyInfo b = new BuddyInfo("here", "123");
        assert(b.getPhoneNumber().equals("123"));
    }

    @Test
    void setPhoneNumber() {
        BuddyInfo b = new BuddyInfo("Jason");
        b.setPhoneNumber("123");
        assert(b.getPhoneNumber().equals("123"));
    }

    @Test
    public void testToString() {
        BuddyInfo b1 = new BuddyInfo("Jason");
        assert(!b1.toString().isEmpty());
    }
}