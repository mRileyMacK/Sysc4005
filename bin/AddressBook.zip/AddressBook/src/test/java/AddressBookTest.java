import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class AddressBookTest {




    @Test
    public void getBuddies() {
        AddressBook book = new AddressBook();
        BuddyInfo b1 = new BuddyInfo("Jason");
        ArrayList<BuddyInfo> testList = new ArrayList<BuddyInfo>();
        assert(book.getBuddies().isEmpty());
    }

    @Test
    public void putBuddy() {
        AddressBook book = new AddressBook();
        BuddyInfo b1 = new BuddyInfo("Jason");

        book.putBuddy(b1);
        ArrayList<BuddyInfo> testList = new ArrayList<BuddyInfo>();
        testList.add(b1);
        assert(book.getBuddies().equals(testList));
    }

    @Test
    public void getBuddy() {
        AddressBook book = new AddressBook();
        BuddyInfo b1 = new BuddyInfo("Jason");

        book.putBuddy(b1);
        assert(book.getBuddy("Jason").getName().equals("Jason"));
    }

    @Test
    public void removeBuddy(){
        AddressBook book = new AddressBook();
        BuddyInfo b1 = new BuddyInfo("Jason");

        book.putBuddy(b1);
        book.removeBuddy("Jason");
        assert(book.getBuddy("Jason") == null);
    }

    @Test
    public void testToString() {
        AddressBook book = new AddressBook();
        BuddyInfo b1 = new BuddyInfo("Jason");
        assert(book.toString().isEmpty());
    }
}