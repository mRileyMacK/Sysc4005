import java.util.ArrayList;

public class AddressBook{
    private ArrayList<BuddyInfo> buddies;
    AddressBook(){
        buddies = new ArrayList<BuddyInfo>();
    }


    public static void main(String[] args){
        AddressBook book = new AddressBook();
        BuddyInfo b1 = new BuddyInfo("Jason");
        BuddyInfo b2 = new BuddyInfo("Thao");
        BuddyInfo b3 = new BuddyInfo("Riley");

        book.putBuddy(b1);
        book.putBuddy(b2);
        book.putBuddy(b3);

        System.out.print(book.toString());
    }

    public ArrayList<BuddyInfo> getBuddies(){
        return buddies;
    }

    public void putBuddy(BuddyInfo buddy){
        buddies.add(buddy);
    }

    public void removeBuddy(String name){
        buddies.removeIf(buddy -> buddy.getName().equals(name));
    }

    public BuddyInfo getBuddy(String name){
        for(BuddyInfo buddy : buddies){
            if(buddy.getName().equals(name)){
                return buddy;
            }
        }
        return null;
    }
    @Override
    public String toString(){
        String ret = "";
        ret.concat("- Address Book Contents -\n");
        int i = 1;
        for(BuddyInfo buddy : buddies){
            ret.concat("Buddy " + i + ": " + buddy.getName() + "\n");
            i++;
        }
        return ret;
    }
}