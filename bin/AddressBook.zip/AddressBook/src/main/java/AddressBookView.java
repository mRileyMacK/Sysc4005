public class AddressBookView {
}
